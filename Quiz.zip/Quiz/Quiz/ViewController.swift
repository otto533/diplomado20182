//
//  ViewController.swift
//  Quiz
//
//  Created by Usuario invitado on 22/2/18.
//  Copyright © 2018 OmarGomez. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let questions: [String] = [
        "Cuánto es 2 + 2?",
        "Quién descubrió América?",
        "Cuántos planetas existen alrededor del Sol?"
    ]
    
    let answers: [String] = [
        "4",
        "Cristóbal Colón",
        "9"
    ]
    
    var currentQuestionIndex: Int = 0
    
    @IBOutlet var questionLabel: UILabel!
    @IBOutlet var answerLabel: UILabel!
    
    @IBAction func showNextQuestion(_ sender: UIButton) {
        currentQuestionIndex += 1
        
        if currentQuestionIndex == questions.count {
            currentQuestionIndex = 0
        }
        
        questionLabel.text = questions[currentQuestionIndex]
        answerLabel.text = "???"
    }
    
    @IBAction func showAnswer(_ sender: UIButton) {
        answerLabel.text = answers[currentQuestionIndex]
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        questionLabel.text = questions[currentQuestionIndex]
    }
}

