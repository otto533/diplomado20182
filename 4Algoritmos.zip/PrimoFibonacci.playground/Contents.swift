//: Playground - noun: a place where people can play

import UIKit

//Función que verifica si un número es primo
func primo (_ n: Int) -> Bool{
    var cont: Int = 0
    
    for i in 1...n {
        if n % i == 0 {
            cont += 1
        }
        
        //Más de 2 divisores ya no es necesario iterar
        if cont > 2 {
            return false
        }
        
    }
    
    return cont == 2
}

//Función que determina el n-ésimo número de la sucesión de fibonacci
func fibonacci(_ n: Int) -> Int{
    if n == 0 {
        return 0
    } else if (n == 1) {
        return 1
    } else {
        return fibonacci(n - 1) + fibonacci(n - 2)
    }
}

//Imprimimos los primeros 20 números de la sucesión de fibonacci e indicamos si son primos
//Sólo imprimí los primeros 20 porque tarda mucho en calcular la serie fibonacci dado que mi algoritmo es recursivo
for i in 1...20 {
    let n: Int = fibonacci(i)
    if primo(n) {
        print("\(n) Es primo")
    } else {
        print("\(n) No es primo")
    }
    print("")
}

