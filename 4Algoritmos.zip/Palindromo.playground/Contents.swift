//: Playground - noun: a place where people can play

import UIKit

//Función que verifica si una cadena es palíndromo

var str: String = "reConOcer"

func palindromo(_ s: String) -> Bool {
    let reversedS = String(s.reversed())
    
    return s.lowercased() == reversedS.lowercased()
}

if palindromo(str) {
    print("\(str) Sí es palíndromo")
} else {
    print("\(str) No es palíndromo")
}

//Funcion que recibe un par de cadenas y verifica si tienen el mismo numero de caracteres y que estos sean los mismo

func compara(_ a: String, _ b: String) -> Bool {
    if a.count != b.count {
        return false
    } else {
        var aux1 = a.sorted()
        var aux2 = b.sorted()
        
        for i in 0...(aux1.count - 1) {
            if aux1[i] == aux2[i] {
                continue
            } else {
                return false
            }
        }
        
        return true
    }
}

if compara("xavgh", "ghavx") {
    print("Contienen lo mismo")
} else {
    print("No contienen lo mismo")
}
